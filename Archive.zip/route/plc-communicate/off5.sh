echo -e ":020500050000F4\r\n" > '/dev/ttyUSB'$1
