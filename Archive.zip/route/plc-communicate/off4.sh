echo -e ":020500040000F5\r\n" > '/dev/ttyUSB'$1
