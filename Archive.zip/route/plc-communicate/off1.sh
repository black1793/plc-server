echo -e ":020500010000F8\r\n" > '/dev/ttyUSB'$1
