echo -e ":02050005FF00F5\r\n" > '/dev/ttyUSB'$1
