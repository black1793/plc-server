echo -e ":020500020000F7\r\n" > '/dev/ttyUSB'$1
