echo -e ":02050001FF00F9\r\n" > '/dev/ttyUSB'$1
