echo -e ":02050003FF00F7\r\n" > '/dev/ttyUSB'$1
