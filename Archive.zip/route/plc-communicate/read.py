import time
t = time
t.sleep(1)
print("READ DATA FROM PLC")