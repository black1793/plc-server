echo -e ":02050000FF00FA\r\n" > '/dev/ttyUSB'$1
