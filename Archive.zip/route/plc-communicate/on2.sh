echo -e ":02050002FF00F8\r\n" > '/dev/ttyUSB'$1
