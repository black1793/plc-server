echo -e ":02050004FF00F6\r\n" > '/dev/ttyUSB'$1
