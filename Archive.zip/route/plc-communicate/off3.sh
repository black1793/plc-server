echo -e ":020500030000F6\r\n" > '/dev/ttyUSB'$1
