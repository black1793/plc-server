echo -e ":020500000000F9\r\n" > '/dev/ttyUSB'$1
